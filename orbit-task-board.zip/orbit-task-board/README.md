# Orbit — personal task board

A dark, responsive task board with nested task workspaces, a stopwatch, and a countdown timer.

## Run locally
Open `index.html` in a modern browser. No build step or dependencies are required.

## Publish with GitHub Pages
1. Create a new GitHub repository (for example, `orbit-task-board`).
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub to publish the site. The Pages URL will appear in the same section.

## Saving and privacy
- Tasks, nested steps, and the session note are saved automatically in the browser's `localStorage`.
- This means the data stays in that browser on that device. GitHub Pages hosts the app files; it does not sync your task data to GitHub or across devices.
- Use **Backup** periodically to download a JSON backup, and **Restore** to import it later.
- Clearing browser site data, using private browsing, or switching browsers/devices can make locally saved data unavailable.
- For automatic cross-device sync, connect a backend such as Supabase or Firebase and add authentication plus database storage. Do not store private task data in a public GitHub repository.

## Notes
- The Google Fonts import is optional; if offline, the app falls back to system fonts.
- Timer and stopwatch run in the current browser tab. The countdown uses the system clock so it remains accurate while navigating between app pages.
